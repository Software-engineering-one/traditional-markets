from googletrans import Translator

def translate_to_korean(text):
    translator = Translator()
    translated = translator.translate(text, src='en', dest='ko')
    return translated.text

def translate_file(input_file, output_file):
    with open(input_file, 'r', encoding='utf-8') as file:
        english_text = file.read()

    korean_text = translate_to_korean(english_text)

    with open(output_file, 'w', encoding='utf-8') as file:
        file.write(korean_text)

input_file = "영어.txt"  
output_file = "한글.txt" 

translate_file(input_file, output_file)
print("번역이 완료되었습니다.")
