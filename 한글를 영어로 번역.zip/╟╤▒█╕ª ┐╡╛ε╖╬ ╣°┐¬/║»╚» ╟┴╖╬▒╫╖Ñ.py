from googletrans import Translator

def translate_korean_to_english(korean_text):
    translator = Translator()
    translated = translator.translate(korean_text, src='ko', dest='en')
    return translated.text

def read_file(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        text = file.read()
    return text

def write_file(file_path, content):
    with open(file_path, 'w', encoding='utf-8') as file:
        file.write(content)

def translate_file(input_file, output_file):
    # 한글 파일 읽기
    korean_text = read_file(input_file)
    
    # 한글을 영어로 번역
    english_text = translate_korean_to_english(korean_text)
    
    # 영어 파일로 쓰기
    write_file(output_file, english_text)

# 번역할 한글 파일 경로
input_file_path = '한글.txt'

# 번역된 영어 파일 경로
output_file_path = '영어.txt'

# 파일 번역 실행
translate_file(input_file_path, output_file_path)

print("번역이 완료되었습니다.")




